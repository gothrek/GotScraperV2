﻿using System;
using System.Windows.Forms;
using System.Drawing;

using Opulos.Core.UI;

namespace Opulos.AlphaColorDialogDemo {

static class Program {
	[STAThread]
	static void Main() {
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);

		Form f = new Form();
		f.StartPosition = FormStartPosition.CenterScreen;
		Button btn = new Button { Text = "Show AlphaColorDialog", AutoSize = true };
		f.Controls.Add(btn);
		AlphaColorDialog acd = new AlphaColorDialog();
		acd.Color = Color.Red;
		acd.ColorChanged += delegate {
			System.Diagnostics.Debug.WriteLine("Color changed: " + acd.Color);
		};

		btn.Click += delegate {
			if (acd.ShowDialog(f) == DialogResult.OK) {
				System.Diagnostics.Debug.WriteLine("Chosen color: " + acd.Color);
			}
		};

		Application.Run(f);
		acd.Dispose();
	}
}
}
